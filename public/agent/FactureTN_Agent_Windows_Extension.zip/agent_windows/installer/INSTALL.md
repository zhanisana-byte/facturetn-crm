# FactureTN Agent (Windows) — Installation (clé USB / token)

## Pré-requis
1) **Windows 10/11** (x64 recommandé).
2) **.NET SDK 8** installé (pour compiler) : https://dotnet.microsoft.com/download
3) Pilotes du token USB + middleware fournisseur (SafeNet/IDPrime/Bit4id… selon votre clé).
4) Votre certificat **ID-Trust sur token** doit être opérationnel sur le poste (PIN OK, certificat visible).

> Le manuel TunTrust décrit l’obtention/commande du certificat **ID-Trust sur token** via le portail ecert.tuntrust.tn. (Voir le PDF fourni, section commande de certificats).  

## 1) Build (compile) l’agent
Ouvrez PowerShell dans `installer/` puis :

```powershell
./build.ps1
```

Cela génère les binaires dans `installer/publish/`.

## 2) Installer l’agent + enregistrer le protocole (deep link)
Toujours dans PowerShell **en administrateur** :

```powershell
./install.ps1
```

Résultat :
- copie l’agent dans `C:\Program Files\FactureTN\Agent\`
- enregistre le protocole `facturetn://` (URL Protocol)
- ajoute un raccourci démarrage (optionnel)

## 3) Tester
Dans PowerShell :

```powershell
Start-Process "facturetn://ping"
```

Puis test de signature (exemple) :
```powershell
Start-Process "facturetn://sign?token=TEST"
```

Le CRM doit fournir le `token` et l’agent appelle ensuite vos endpoints `/api/signature/agent/*`.

## Désinstaller
PowerShell admin :
```powershell
./uninstall.ps1
```

## Notes importantes (signature)
- L’agent produit une **XMLDSIG enveloped SHA-256**.
- Si TTN impose **XAdES**, l’enrichissement XAdES doit être fait côté CRM.
