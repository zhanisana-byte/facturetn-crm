param(
  [string]$InstallDir = "$env:ProgramFiles\FactureTN\Agent",
  [string]$Protocol = "facturetn"
)

$ErrorActionPreference = "Stop"

# Remove protocol registration
$k = "HKCU:\Software\Classes\$Protocol"
if (Test-Path $k) { Remove-Item $k -Recurse -Force }

# Remove installed files
if (Test-Path $InstallDir) { Remove-Item $InstallDir -Recurse -Force }

Write-Host "OK: Agent désinstallé." -ForegroundColor Green
