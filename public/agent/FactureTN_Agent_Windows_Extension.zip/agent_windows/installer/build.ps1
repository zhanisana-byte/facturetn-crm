param(
  [string]$Runtime = "win-x64",
  [switch]$SelfContained = $true
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$agentProj = Join-Path $root "..\src\agent\FactureTN.Agent\FactureTN.Agent.csproj"
$outDir = Join-Path $root "publish"

if (Test-Path $outDir) { Remove-Item $outDir -Recurse -Force }

Write-Host "Publishing FactureTN.Agent -> $outDir" -ForegroundColor Cyan

dotnet publish $agentProj -c Release -r $Runtime `
  /p:PublishSingleFile=true `
  /p:IncludeNativeLibrariesForSelfExtract=true `
  /p:SelfContained=$($SelfContained.IsPresent) `
  -o $outDir

Write-Host "OK: publish done." -ForegroundColor Green
