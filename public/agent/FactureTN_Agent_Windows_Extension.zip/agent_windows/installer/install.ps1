param(
  [string]$InstallDir = "$env:ProgramFiles\FactureTN\Agent",
  [string]$Protocol = "facturetn"
)

$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$publish = Join-Path $root "publish"
$exe = Join-Path $publish "FactureTN.Agent.exe"

if (!(Test-Path $exe)) {
  throw "Binaire non trouvé: $exe. Lancez d'abord .\build.ps1"
}

# Copy files
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
Copy-Item (Join-Path $publish "*") $InstallDir -Recurse -Force

$exeInstalled = Join-Path $InstallDir "FactureTN.Agent.exe"

# Register URL protocol (HKCU for per-user; HKLM possible if you want machine-wide)
$k = "HKCU:\Software\Classes\$Protocol"
New-Item -Path $k -Force | Out-Null
New-ItemProperty -Path $k -Name "(Default)" -Value "URL:FactureTN Agent Protocol" -Force | Out-Null
New-ItemProperty -Path $k -Name "URL Protocol" -Value "" -Force | Out-Null

$cmdKey = Join-Path $k "shell\open\command"
New-Item -Path $cmdKey -Force | Out-Null

# %1 is the full URL (facturetn://...)
$cmd = "`"$exeInstalled`" `"%1`""
New-ItemProperty -Path $cmdKey -Name "(Default)" -Value $cmd -Force | Out-Null

Write-Host "OK: Agent installé dans $InstallDir" -ForegroundColor Green
Write-Host "OK: Protocole '$Protocol://' enregistré pour l'utilisateur courant (HKCU)." -ForegroundColor Green

Write-Host ""
Write-Host "Test: Start-Process `"$Protocol://ping`"" -ForegroundColor Yellow
