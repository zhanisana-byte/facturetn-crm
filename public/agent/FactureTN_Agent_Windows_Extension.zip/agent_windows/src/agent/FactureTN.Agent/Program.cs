\
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.Json;
using System.Web;
using System.Windows.Forms;

namespace FactureTN.Agent;

internal static class Program
{
    [STAThread]
    static void Main(string[] args)
    {
        try
        {
            ApplicationConfiguration.Initialize();

            var raw = args != null && args.Length > 0 ? args[0] : "";
            if (string.IsNullOrWhiteSpace(raw))
            {
                MessageBox.Show("FactureTN Agent est installé.\n\nUtilise le bouton \"Associer clé\" depuis FactureTN.", "FactureTN Agent");
                return;
            }

            if (!Uri.TryCreate(raw, UriKind.Absolute, out var uri))
            {
                MessageBox.Show($"Lien invalide:\n{raw}", "FactureTN Agent");
                return;
            }

            var allowedSchemes = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "facturetn-agent", "facturetn" };

            if (!allowedSchemes.Contains(uri.Scheme))
            {
                MessageBox.Show($"Schéma non supporté: {uri.Scheme}

Schémas supportés: facturetn-agent, facturetn", "FactureTN Agent");
                return;
            }

            var action = (uri.Host ?? "").Trim().ToLowerInvariant(); // pair | sign
            var qs = HttpUtility.ParseQueryString(uri.Query);

            var server = (qs.Get("server") ?? "").Trim();
            if (string.IsNullOrWhiteSpace(server))
            {
                // fallback: allow env var for dev
                server = Environment.GetEnvironmentVariable("FACTURETN_SERVER_URL") ?? "";
            }
            server = server.TrimEnd('/');

            if (string.IsNullOrWhiteSpace(server))
            {
                MessageBox.Show("Paramètre 'server' manquant.\n\nEx: facturetn-agent://pair?server=https://ton-site.tn&token=...", "FactureTN Agent");
                return;
            }

            var token = (qs.Get("token") ?? "").Trim();
            var companyId = (qs.Get("company_id") ?? "").Trim();
            var env = (qs.Get("env") ?? "production").Trim().ToLowerInvariant();

            if (action == "pair")
            {
                if (string.IsNullOrWhiteSpace(token) || string.IsNullOrWhiteSpace(companyId))
                {
                    MessageBox.Show("Paramètres manquants pour pair: token + company_id", "FactureTN Agent");
                    return;
                }

                DoPair(server, token, companyId, env);
                return;
            }

            if (action == "sign")
            {
                if (string.IsNullOrWhiteSpace(token))
                {
                    MessageBox.Show("Paramètre manquant pour sign: token", "FactureTN Agent");
                    return;
                }

                DoSign(server, token);
                return;
            }

            MessageBox.Show($"Action inconnue: {action}", "FactureTN Agent");
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.ToString(), "FactureTN Agent - Erreur");
        }
    }

    private static void DoSign(string server, string token)
    {
        // 1) Récupérer le TEIF à signer
        try
        {
            using var http = new HttpClient();
            http.Timeout = TimeSpan.FromSeconds(30);

            var payloadUrl = $"{server}/api/signature/agent/sign-payload?token={HttpUtility.UrlEncode(token)}";
            var resp = http.GetAsync(payloadUrl).GetAwaiter().GetResult();
            var body = resp.Content.ReadAsStringAsync().GetAwaiter().GetResult();

            if (!resp.IsSuccessStatusCode)
            {
                MessageBox.Show($"Échec payload ({(int)resp.StatusCode}).\n\n{body}", "FactureTN Agent");
                return;
            }

            var json = JsonDocument.Parse(body);
            var ok = json.RootElement.GetProperty("ok").GetBoolean();
            if (!ok)
            {
                MessageBox.Show(body, "FactureTN Agent");
                return;
            }

            var xml = json.RootElement.GetProperty("xml").GetString() ?? "";
            var thumbprint = json.RootElement.TryGetProperty("thumbprint", out var t) ? (t.GetString() ?? "") : "";
            if (string.IsNullOrWhiteSpace(xml))
            {
                MessageBox.Show("XML vide.", "FactureTN Agent");
                return;
            }

            // 2) Choisir le certificat
            var certs = ListUserCertificatesWithPrivateKey();
            if (certs.Count == 0)
            {
                MessageBox.Show("Aucun certificat utilisable trouvé.", "FactureTN Agent");
                return;
            }

            X509Certificate2? selected = null;
            if (!string.IsNullOrWhiteSpace(thumbprint))
            {
                selected = certs.FirstOrDefault(c => string.Equals(c.Thumbprint, thumbprint, StringComparison.OrdinalIgnoreCase));
            }

            if (selected is null)
            {
                using var picker = new CertPickerForm(certs);
                if (picker.ShowDialog() != DialogResult.OK || picker.Selected is null)
                    return;
                selected = picker.Selected;
            }

            // 3) Signer (déclenche PIN au besoin)
            string signedXml;
            try
            {
                signedXml = XmlSigner.SignEnveloped(xml, selected);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erreur signature (PIN/clé privée ?)\n\n" + ex.Message, "FactureTN Agent");
                return;
            }

            // 4) Envoyer XML signé au serveur
            var postUrl = $"{server}/api/signature/agent/signed-xml";
            var payload = new
            {
                token,
                signed_xml = signedXml,
                cert = new
                {
                    thumbprint = selected.Thumbprint,
                    serial_number = selected.SerialNumber,
                    subject = selected.Subject,
                    issuer = selected.Issuer,
                }
            };

            var resp2 = http.PostAsJsonAsync(postUrl, payload).GetAwaiter().GetResult();
            var body2 = resp2.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            if (!resp2.IsSuccessStatusCode)
            {
                MessageBox.Show($"Échec envoi XML signé ({(int)resp2.StatusCode}).\n\n{body2}", "FactureTN Agent");
                return;
            }

            MessageBox.Show("✅ Signature enregistrée dans FactureTN.\n\nRetournez sur la facture pour télécharger XML signé / envoyer TTN.", "FactureTN Agent");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Erreur signature.\n\n" + ex, "FactureTN Agent");
        }
    }

    private static void DoPair(string server, string token, string companyId, string env)
    {
        // 1) Liste certificats utilisateur avec clé privée (USB/Store)
        var certs = ListUserCertificatesWithPrivateKey();
        if (certs.Count == 0)
        {
            MessageBox.Show("Aucun certificat utilisable trouvé.\n\nBranche ta clé USB (certificat) puis réessaie.", "FactureTN Agent");
            return;
        }

        // 2) UI: choisir
        using var picker = new CertPickerForm(certs);
        if (picker.ShowDialog() != DialogResult.OK || picker.Selected is null)
        {
            return;
        }

        var selected = picker.Selected;

        // 3) Toucher la clé privée pour déclencher éventuellement la demande PIN par le fournisseur (CSP/Minidriver)
        try
        {
            _ = selected.GetRSAPrivateKey() ?? selected.GetECDsaPrivateKey();
        }
        catch (Exception e)
        {
            MessageBox.Show("Impossible d'accéder à la clé privée.\n\n" + e.Message, "FactureTN Agent");
            return;
        }

        // 4) Envoyer association au serveur (la clé privée NE sort jamais)
        var payload = new
        {
            token,
            company_id = companyId,
            environment = env,
            cert = new
            {
                thumbprint = selected.Thumbprint,
                serial_number = selected.SerialNumber,
                subject = selected.Subject,
                issuer = selected.Issuer,
                not_before = selected.NotBefore,
                not_after = selected.NotAfter
            }
        };

        try
        {
            using var http = new HttpClient();
            http.Timeout = TimeSpan.FromSeconds(30);

            var url = $"{server}/api/signature/agent/pair";
            var resp = http.PostAsJsonAsync(url, payload).GetAwaiter().GetResult();

            var body = resp.Content.ReadAsStringAsync().GetAwaiter().GetResult();
            if (!resp.IsSuccessStatusCode)
            {
                MessageBox.Show($"Échec pairing ({(int)resp.StatusCode}).\n\n{body}", "FactureTN Agent");
                return;
            }

            MessageBox.Show("✅ Clé associée avec succès à la société.\n\nTu peux maintenant signer/envoyer TTN depuis FactureTN.", "FactureTN Agent");
        }
        catch (Exception ex)
        {
            MessageBox.Show("Erreur réseau vers FactureTN.\n\n" + ex.Message, "FactureTN Agent");
        }
    }

    private static List<X509Certificate2> ListUserCertificatesWithPrivateKey()
    {
        var result = new List<X509Certificate2>();
        void Scan(StoreLocation loc)
        {
            using var store = new X509Store(StoreName.My, loc);
            store.Open(OpenFlags.ReadOnly);
            foreach (var cert in store.Certificates)
            {
                try
                {
                    if (!cert.HasPrivateKey) continue;
                    // ignore expired
                    if (DateTime.Now < cert.NotBefore || DateTime.Now > cert.NotAfter) continue;
                    // basic filter: exclude test/self-signed unless needed
                    result.Add(cert);
                }
                catch { /* ignore */ }
            }
        }

        Scan(StoreLocation.CurrentUser);
        // Optionnel: machine store (souvent admin)
        // Scan(StoreLocation.LocalMachine);

        // dedupe by thumbprint
        return result
            .GroupBy(c => c.Thumbprint ?? "")
            .Select(g => g.First())
            .Where(c => !string.IsNullOrWhiteSpace(c.Thumbprint))
            .OrderByDescending(c => c.NotAfter)
            .ToList();
    }
}
