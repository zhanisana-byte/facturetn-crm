using System;
using System.Security.Cryptography;
using System.Security.Cryptography.Xml;
using System.Security.Cryptography.X509Certificates;
using System.Xml;

namespace FactureTN.Agent;

internal static class XmlSigner
{
    // Algorithmes SHA-256 (évite les valeurs par défaut qui peuvent être refusées par certains validateurs)
    private const string XmlDsigSha256Url = "http://www.w3.org/2001/04/xmlenc#sha256";
    private const string XmlDsigRsaSha256Url = "http://www.w3.org/2001/04/xmldsig-more#rsa-sha256";
    private const string XmlDsigEcdsaSha256Url = "http://www.w3.org/2001/04/xmldsig-more#ecdsa-sha256";

    /// <summary>
    /// Signature XML enveloped (XMLDSIG) avec un certificat présent sur le poste (token USB inclus).
    /// - Déclenche le PIN au niveau CSP/minidriver si nécessaire (aucun PIN n'est stocké côté agent).
    /// - Conserve PreserveWhitespace=true pour ne pas casser le digest.
    ///
    /// IMPORTANT :
    /// - Cette signature est une XMLDSIG enveloped (pas XAdES).
    /// - Si TTN impose XAdES-BES/EPES, il faudra enrichir côté CRM (SignedProperties, QualifyingProperties...).
    /// </summary>
    public static string SignEnveloped(string xml, X509Certificate2 cert)
    {
        if (string.IsNullOrWhiteSpace(xml)) throw new ArgumentException("XML vide");
        if (cert is null) throw new ArgumentNullException(nameof(cert));
        if (!cert.HasPrivateKey) throw new InvalidOperationException("Certificat sans clé privée");

        var doc = new XmlDocument { PreserveWhitespace = true };
        doc.LoadXml(xml);

        var signedXml = new SignedXml(doc);

        // Sélection de clé privée (RSA ou ECDSA)
        AsymmetricAlgorithm? key = cert.GetRSAPrivateKey();
        bool isRsa = key != null;
        if (key == null)
        {
            key = cert.GetECDsaPrivateKey();
            isRsa = false;
        }
        if (key == null) throw new InvalidOperationException("Impossible d'obtenir la clé privée (RSA/ECDSA)");

        signedXml.SigningKey = key;

        // Canonicalisation exclusive (souvent plus compatible)
        signedXml.SignedInfo.CanonicalizationMethod = SignedXml.XmlDsigExcC14NTransformUrl;

        // SignatureMethod explicite en SHA-256
        signedXml.SignedInfo.SignatureMethod = isRsa ? XmlDsigRsaSha256Url : XmlDsigEcdsaSha256Url;

        // Référence au document entier (enveloped)
        var reference = new Reference("")
        {
            DigestMethod = XmlDsigSha256Url
        };
        reference.AddTransform(new XmlDsigEnvelopedSignatureTransform());
        reference.AddTransform(new XmlDsigExcC14NTransform());
        signedXml.AddReference(reference);

        // Inclure le certificat dans KeyInfo
        var keyInfo = new KeyInfo();
        keyInfo.AddClause(new KeyInfoX509Data(cert));
        signedXml.KeyInfo = keyInfo;

        // Calcul signature (déclenche PIN si token)
        signedXml.ComputeSignature();

        // Append Signature
        var xmlDigitalSignature = signedXml.GetXml();
        doc.DocumentElement?.AppendChild(doc.ImportNode(xmlDigitalSignature, true));

        return doc.OuterXml;
    }
}
