# FactureTN Agent (DeepLink) - MVP Windows

## But
Associer une clé USB/certificat à une société via un lien DeepLink :
`facturetn-agent:// (ou facturetn:// si vous choisissez ce schéma)pair?server=https://votre-domaine&token=...&company_id=...&env=production`

- Le certificat est sélectionné localement (Windows Store / USB).
- Le PIN est géré par Windows/CSP (l'agent ne stocke jamais le PIN).
- L'agent envoie au serveur uniquement les métadonnées du certificat (thumbprint/serial/expiry), jamais la clé privée.

## Build
- Windows
- .NET 8 SDK

```bash
cd agent/FactureTN.Agent
dotnet build -c Release
```

## Enregistrer le protocole deep link (dev)
Exécute PowerShell en Admin :

```powershell
.
egister-protocol.ps1 "C:\chemin\vers\FactureTNAgent.exe"
```

## Serveur
L'agent appelle :
POST {server}/api/signature/agent/pair
avec le JSON { token, company_id, environment, cert:{...} }
